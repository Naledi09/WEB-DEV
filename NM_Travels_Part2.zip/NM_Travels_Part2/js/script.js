document.addEventListener('DOMContentLoaded', () => {
  // Mobile navigation toggle
  const menu = document.querySelector('.menu');
  const nav = document.querySelector('nav');
  if (menu) {
    menu.addEventListener('click', () => {
      nav.style.display = nav.style.display === 'flex' ? 'none' : 'flex';
    });
  }

  // Home page: route search
  const routeSearchForm = document.getElementById('routeSearch');
  const searchResult = document.getElementById('searchResult');
  if (routeSearchForm) {
    routeSearchForm.addEventListener('submit', e => {
      e.preventDefault();
      const from = document.getElementById('from').value;
      const to = document.getElementById('to').value;
      const date = document.getElementById('date').value;
      searchResult.hidden = false;
      searchResult.textContent = from === to
        ? 'Pickup and destination must be different.'
        : `Search received for ${from} to ${to} on ${date}. Matching departures would appear here in the full system.`;
    });
  }

  // Routes page: table filter
  const filter = document.getElementById('filter');
  const routeRows = document.querySelectorAll('#routeTable tbody tr');
  if (filter) {
    filter.addEventListener('change', () => {
      routeRows.forEach(row => {
        row.style.display = filter.value === 'all' || row.dataset.type === filter.value ? '' : 'none';
      });
    });
  }

  // Booking page: seat booking form
  const bookingForm = document.getElementById('bookingForm');
  const bookingResult = document.getElementById('bookingResult');
  if (bookingForm) {
    bookingForm.addEventListener('submit', e => {
      e.preventDefault();
      const pickup = document.getElementById('pickup').value;
      const dropoff = document.getElementById('dropoff').value;
      const name = document.getElementById('name').value;
      if (pickup === dropoff) {
        bookingResult.hidden = false;
        bookingResult.textContent = 'Pickup and drop-off must be different.';
        return;
      }
      bookingResult.hidden = false;
      bookingResult.textContent = `Thank you, ${name}. Your booking request has been recorded for this academic demonstration.`;
      bookingForm.reset();
    });
  }

  // Charter page: private charter enquiry form
  const charterForm = document.getElementById('charterForm');
  const charterResult = document.getElementById('charterResult');
  if (charterForm) {
    charterForm.addEventListener('submit', e => {
      e.preventDefault();
      charterResult.hidden = false;
      charterResult.textContent = 'Your private charter enquiry has been recorded for this demonstration. A real system would route it to the sales inbox.';
      charterForm.reset();
    });
  }

  // About page: contact form
  const contactForm = document.getElementById('contactForm');
  const contactResult = document.getElementById('contactResult');
  if (contactForm) {
    contactForm.addEventListener('submit', e => {
      e.preventDefault();
      contactResult.hidden = false;
      contactResult.textContent = 'Your message has been recorded for this demonstration. A real implementation would send it to the company inbox.';
      contactForm.reset();
    });
  }
});
